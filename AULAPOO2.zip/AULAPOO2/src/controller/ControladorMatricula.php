<?php
namespace Admin\Aulapoo1\controller;

use Admin\Aulapoo1\model\Usuario;

class UsuarioController {
    private $usuarios = [];

    public function __construct() {
        // Exemplo inicial: lista com um usuário
        $this->usuarios[] = new Usuario(1, "João Silva", "joao@email.com", "1234");
    }

    public function listarUsuarios() {
        return $this->usuarios;
    }

    public function adicionarUsuario($id, $nome, $email, $senha) {
        $novoUsuario = new Usuario($id, $nome, $email, $senha);
        $this->usuarios[] = $novoUsuario;
        return $novoUsuario;
    }

    public function buscarUsuarioPorId($id) {
        foreach ($this->usuarios as $usuario) {
            if ($usuario->idUsuario == $id) {
                return $usuario;
            }
        }
        return null;
    }
}
