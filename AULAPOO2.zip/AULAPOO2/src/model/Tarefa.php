<?php
class Tarefa {
    private $idTarefa;
    private $tituloTarefa;
    private $descricaoTarefa;
    private $idAluno;

    public function getInfoTarefa(): string {
       return $this->idTarefa = $idTarefa;
       return $this->tituloTarefa = $tituloTarefa;
       return $this->descricaoTarefa = $descricaoTarefa;
       return $this->idAluno = $idAluno;
    }
}
