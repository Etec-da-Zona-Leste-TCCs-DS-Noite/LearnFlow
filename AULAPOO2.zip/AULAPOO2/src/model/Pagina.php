<?php
class Pagina {
    private $idPagina;
    private $tituloPagina;
    private $conteudoPagina;
    private $idUsuario;

    public function getInfoPagina(): string {
       return $this->idPagina = $idPagina;
       return $this->tituloPagina = $tituloPagina;
       return $this->conteudoPagina = $conteudoPagina;
       return $this->idUsuario = $idUsuario;
    }
}
