<?php
class Blocodeconteudo {
    private $idBloco;
    private $tipoBloco;
    private $conteudoBloco;
    private $idPagina;

    public function getInfoBlocCont(): string {
       return $this->idBloco = $idBloco;
       return $this->tipoBloco = $tipoBloco;
       return $this->conteudoBloco = $conteudoBloco;
       return $this->idPagina = $idPagina;
    }
}
