<?php
class Materia {
    private $idMateria;
    private $nomeMateria;
    private $descricaoMateria;

    public function getInfoMateria(): string {
       return $this->idMateria = $idMateria;
       return $this->nomeMateria = $nomeMateria;
       return $this->descricaoMateria = $descricaoMateria;
    }
}
