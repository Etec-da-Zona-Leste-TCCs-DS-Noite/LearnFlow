<?php
class Aluno {
    private $idAluno;
    private $nomeAluno;
    private $emailAluno;
    private $matriculaAluno;

    public function getInfoAluno(): string {
        return $this->idAluno = $idAluno;
        return $this->nomeAluno = $nomeAluno;
        return $this->emailAluno = $emailAluno;
        return $this->matriculaAluno = $matriculaAluno;
    }
}
