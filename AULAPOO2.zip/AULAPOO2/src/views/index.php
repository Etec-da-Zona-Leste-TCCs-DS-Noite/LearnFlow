<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Admin\Aulapoo1\model\Aluno;
use Admin\Aulapoo1\model\Materia;
use Admin\Aulapoo1\model\Pagina;
use Admin\Aulapoo1\model\Tarefa;
use Admin\Aulapoo1\model\Usuario;
use Admin\Aulapoo1\model\Blocodeconteudo;

echo "<h1>📘 Lear Flow - Organizador de Estudos</h1>";
echo "<p>Bem-vindo ao seu ambiente de estudos!</p>";

$usuario = new Usuario(1, "João Silva", "joao@email.com", "1234");
$aluno = new Aluno(1, "João Silva", "joao@email.com", "2025001");
$materia = new Materia(1, "Programação Orientada a Objetos", "Conceitos e prática em PHP");
$pagina = new Pagina(1, "Resumo da Aula 01", "Conceitos básicos de classes e objetos", $usuario->idUsuario);
$tarefa = new Tarefa(1, "Revisar código", "Rever as classes do projeto", $aluno->idAluno);
$bloco = new Blocodeconteudo(1, "texto", "Anotações de aula sobre encapsulamento", $pagina->idPagina);

echo "<pre>";
print_r($usuario);
print_r($aluno);
print_r($materia);
print_r($pagina);
print_r($tarefa);
print_r($bloco);
echo "</pre>";
